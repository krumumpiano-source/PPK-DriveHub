const API = (() => {
  const BASE = '';  // relative paths — works on any domain

  function getToken() {
    return localStorage.getItem('ppk_token') || sessionStorage.getItem('ppk_token');
  }
  function setToken(t, remember = true) {
    if (t) {
      if (remember) localStorage.setItem('ppk_token', t);
      else sessionStorage.setItem('ppk_token', t);
    } else {
      localStorage.removeItem('ppk_token');
      sessionStorage.removeItem('ppk_token');
    }
  }
  function clearAuth() {
    setToken(null);
    localStorage.removeItem('ppk_user');
    sessionStorage.removeItem('ppk_user');
  }
  function getUser() {
    try { return JSON.parse(localStorage.getItem('ppk_user') || sessionStorage.getItem('ppk_user') || 'null'); }
    catch { return null; }
  }
  function setUser(u) {
    const s = JSON.stringify(u);
    if (localStorage.getItem('ppk_token')) localStorage.setItem('ppk_user', s);
    else sessionStorage.setItem('ppk_user', s);
  }

  async function request(path, options = {}) {
    const token = getToken();
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    if (options.body && typeof options.body !== 'string') {
      options.body = JSON.stringify(options.body);
    }
    let resp;
    try {
      resp = await fetch(BASE + path, { ...options, headers });
    } catch (e) {
      throw new Error('ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาตรวจสอบอินเตอร์เน็ต');
    }
    const data = await resp.json().catch(() => ({ success: false, message: `HTTP ${resp.status}` }));
    if (resp.status === 401) {
      clearAuth();
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login.html';
      }
      throw new Error(data.error || data.message || 'กรุณาเข้าสู่ระบบใหม่');
    }
    if (!resp.ok) throw new Error(data.message || data.error || `HTTP ${resp.status}`);
    return data;
  }

  function startImpersonate(token, userData) {
    // Save original admin credentials
    localStorage.setItem('ppk_orig_token', getToken());
    localStorage.setItem('ppk_orig_user', localStorage.getItem('ppk_user') || sessionStorage.getItem('ppk_user'));
    // Switch to impersonated user
    localStorage.setItem('ppk_token', token);
    setUser(userData);
  }

  function stopImpersonate() {
    var origToken = localStorage.getItem('ppk_orig_token');
    var origUser = localStorage.getItem('ppk_orig_user');
    if (origToken) {
      localStorage.setItem('ppk_token', origToken);
      localStorage.removeItem('ppk_orig_token');
    }
    if (origUser) {
      localStorage.setItem('ppk_user', origUser);
      localStorage.removeItem('ppk_orig_user');
    }
  }

  function isImpersonating() {
    return !!localStorage.getItem('ppk_orig_token');
  }

  return {
    getToken, setToken, clearAuth, getUser, setUser,
    startImpersonate, stopImpersonate, isImpersonating,
    get:  (path) => request(path, { method: 'GET' }),
    post: (path, body) => request(path, { method: 'POST', body }),
    put:  (path, body) => request(path, { method: 'PUT', body }),
    del:  (path) => request(path, { method: 'DELETE' }),
  };
})();

// Backward-Compat Bridge: apiCall(action, data)
// Maps old GAS action names → new REST endpoints
const ACTION_MAP = {
  // Auth
  'login':               (d) => API.post('/api/auth/login', d),
  'register':            (d) => API.post('/api/auth/register', d),
  'logout':              ()  => API.post('/api/auth/logout'),
  'getMe':               ()  => API.get('/api/auth/me'),
  'changePassword':      (d) => API.post('/api/auth/change-password', d),
  'forgotPassword':      (d) => API.post('/api/auth/forgot-password', d),
  'resetPassword':       (d) => API.post('/api/auth/reset-password', d),
  'acceptPdpa':          (d) => API.post('/api/auth/accept-pdpa', d),
  'updateProfile':       (d) => API.put('/api/auth/profile', d),

  // Vehicles
  'getVehicles':         (d) => API.get('/api/vehicles' + _q(d)),
  'getVehicle':          (d) => API.get(`/api/vehicles/${d.id}`),
  'createVehicle':       (d) => API.post('/api/vehicles', d),
  'updateVehicle':       (d) => API.put(`/api/vehicles/${d.id}`, d),
  'deactivateVehicle':   (d) => API.put(`/api/vehicles/${d.id}/deactivate`, d),
  'getInactiveVehicles': ()  => API.get('/api/vehicles/inactive'),
  'reactivateVehicle':   (d) => API.put(`/api/vehicles/${d.id}/reactivate`, d),

  // Drivers
  'getDrivers':          (d) => API.get('/api/drivers' + _q(d)),
  'getDriver':           (d) => API.get(`/api/drivers/${d.id}`),
  'createDriver':        (d) => API.post('/api/drivers', d),
  'updateDriver':        (d) => API.put(`/api/drivers/${d.id}`, d),
  'deactivateDriver':    (d) => API.del(`/api/drivers/${d.id}`),
  'reportFatigue':       (d) => API.post('/api/drivers/fatigue', d),
  'getDriverLeaves':     (d) => API.get(`/api/drivers/${d.id}/leaves`),
  'createDriverLeave':   (d) => API.post(`/api/drivers/${d.id}/leaves`, d),
  'deleteDriverLeave':   (d) => API.del(`/api/drivers/leaves/${d.leaveId}`),

  // Queue
  'getQueue':            (d) => API.get('/api/queue' + _q(d)),
  'getQueueItem':        (d) => API.get(`/api/queue/${d.id}`),
  'createQueue':         (d) => API.post('/api/queue', d),
  'updateQueue':         (d) => API.put(`/api/queue/${d.id}`, d),
  'cancelQueue':         (d) => API.put(`/api/queue/${d.id}/cancel`, d),
  'freezeQueue':         (d) => API.put(`/api/queue/${d.id}/freeze`, d),
  'unfreezeQueue':       (d) => API.put(`/api/queue/${d.id}/unfreeze`, d),
  'completeQueue':       (d) => API.put(`/api/queue/${d.id}/complete`, d),
  'getQueueTimeline':    (d) => API.get('/api/queue/timeline' + _q(d)),
  'getQueueRules':       ()  => API.get('/api/queue/rules'),
  'updateQueueRules':    (d) => API.put('/api/queue/rules', d),

  // Fuel
  'getFuelLog':          (d) => API.get('/api/fuel/log' + _q(d)),
  'getFuelItem':         (d) => API.get(`/api/fuel/${d.id}`),
  'createFuel':          (d) => API.post('/api/fuel/record', d),
  'updateFuel':          (d) => API.put(`/api/fuel/${d.id}`, d),
  'getFuelTypes':        ()  => API.get('/api/fuel/types'),
  'getFuelReports':      (d) => API.get('/api/fuel/reports' + _q(d)),
  'getFuelRequests':     (d) => API.get('/api/fuel/requests' + _q(d)),
  'createFuelRequest':   (d) => API.post('/api/fuel/requests', d),
  'approveFuelRequest':  (d) => API.put(`/api/fuel/requests/${d.id}/approve`, d),
  'rejectFuelRequest':   (d) => API.put(`/api/fuel/requests/${d.id}/reject`, d),
  'getFuelInvoices':     (d) => API.get('/api/fuel/invoices' + _q(d)),
  'createFuelInvoice':   (d) => API.post('/api/fuel/invoices', d),
  'getFuelInvoiceReconcile': (d) => API.get(`/api/fuel/invoices/${d.id}/reconcile`),
  'resolveFuelInvoice':  (d) => API.put(`/api/fuel/invoices/${d.id}/resolve`, d),
  'getFuelLedger':        (d) => API.get('/api/fuel/ledger' + _q(d)),
  'getFuelMonthlySummary': (d) => API.get('/api/fuel/monthly-summary' + _q(d)),
  'getFuelBudgets':       (d) => API.get('/api/fuel/budgets' + _q(d)),
  'createFuelBudget':     (d) => API.post('/api/fuel/budgets', d),
  'updateFuelBudget':     (d) => API.put(`/api/fuel/budgets/${d.id}`, d),
  'deleteFuelBudget':     (d) => API.del(`/api/fuel/budgets/${d.id}`),

  // Repair
  'getRepairs':          (d) => API.get('/api/repair/log' + _q(d)),
  'getRepair':           (d) => API.get(`/api/repair/log/${d.id}`),
  'createRepair':        (d) => API.post('/api/repair/log', d),
  'updateRepair':        (d) => API.put(`/api/repair/log/${d.id}`, d),
  'deleteRepair':        (d) => API.del(`/api/repair/log/${d.id}`),
  'approveRepair':       (d) => API.put(`/api/repair/log/${d.id}/approve`, d),
  'rejectRepair':        (d) => API.put(`/api/repair/log/${d.id}/reject`, d),
  'inspectRepair':       (d) => API.put(`/api/repair/log/${d.id}/inspect`, d),
  'documentRepair':      (d) => API.put(`/api/repair/log/${d.id}/document`, d),
  'startRepair':         (d) => API.put(`/api/repair/log/${d.id}/start-repair`, d),
  'completeRepair':      (d) => API.put(`/api/repair/log/${d.id}/complete`, d),
  'getScheduledRepairs': (d) => API.get('/api/repair/scheduled' + _q(d)),
  'createScheduledRepair':(d) => API.post('/api/repair/scheduled', d),

  // Usage
  'getUsageLog':         (d) => API.get('/api/usage' + _q(d)),
  'getUsageItem':        (d) => API.get(`/api/usage/${d.id}`),
  'createUsage':         (d) => API.post('/api/usage', d),
  'updateUsage':         (d) => API.put(`/api/usage/${d.id}`, d),
  'createUsagePublic':   (d) => API.post('/api/usage/record', d),
  'getUsageLatestStatus':(d) => API.get('/api/usage/latest-status' + _q(d)),
  'getUsageRecords':     (d) => API.get('/api/usage' + _q(d)),

  // Daily Check
  'getCheckLog':         (d) => API.get('/api/check/log' + _q(d)),
  'getCheckAlerts':      (d) => API.get('/api/check/alerts' + _q(d)),
  'resolveAlert':        (d) => API.put(`/api/check/alerts/${d.id}/resolve`, d),

  // Tax & Insurance
  'getTaxRecords':       (d) => API.get('/api/tax-insurance/tax' + _q(d)),
  'createTaxRecord':     (d) => API.post('/api/tax-insurance/tax', d),
  'updateTaxRecord':     (d) => API.put(`/api/tax-insurance/tax/${d.id}`, d),
  'getInsuranceRecords': (d) => API.get('/api/tax-insurance/insurance' + _q(d)),
  'createInsurance':     (d) => API.post('/api/tax-insurance/insurance', d),
  'updateInsurance':     (d) => API.put(`/api/tax-insurance/insurance/${d.id}`, d),
  'getExpiringDocs':     (d) => API.get('/api/tax-insurance/expiring' + _q(d)),

  // Reports
  'getDashboard':        ()  => API.get('/api/reports/dashboard'),
  'getFuelAnalysis':     (d) => API.get('/api/reports/fuel' + _q(d)),
  'getUsageReport':      (d) => API.get('/api/reports/usage' + _q(d)),
  'getRepairReport':     (d) => API.get('/api/reports/repair' + _q(d)),
  'getHealthReport':     ()  => API.get('/api/reports/health'),
  'getDriversReport':    (d) => API.get('/api/reports/drivers' + _q(d)),

  // Maintenance
  'getMaintenanceSettings': () => API.get('/api/maintenance/settings'),
  'updateMaintenanceSetting': (d) => API.put(`/api/maintenance/settings/${d.id}`, d),
  'bulkUpdateMaintenanceSettings': (d) => API.put('/api/maintenance/settings/bulk', d),
  'getMaintenanceSchedule': () => API.get('/api/maintenance/schedule'),
  'getMaintenanceAlerts':  (d) => API.get('/api/maintenance/alerts' + _q(d)),
  'createMaintenanceAlert':(d) => API.post('/api/maintenance/alerts', d),
  'resolveMaintenanceAlert':(d) => API.put(`/api/maintenance/alerts/${d.id}/resolve`, d),
  'getMaintenanceVehicle': (d) => API.get(`/api/maintenance/vehicle/${d.car_id}`),
  'postMaintenanceVehicle':(d) => API.post('/api/maintenance/vehicle', d),
  // Maintenance Profiles
  'getMaintenanceProfiles':     (d) => API.get('/api/maintenance/profiles' + _q(d)),
  'getMaintenanceProfileBrands':() => API.get('/api/maintenance/profiles/brands'),
  'createMaintenanceProfile':   (d) => API.post('/api/maintenance/profiles', d),
  'updateMaintenanceProfile':   (d) => API.put(`/api/maintenance/profiles/${d.id}`, d),
  'deleteMaintenanceProfile':   (d) => API.del(`/api/maintenance/profiles/${d.id}`),
  'getMaintenanceVehicleProfiles': (d) => API.get(`/api/maintenance/profiles/vehicle/${d.car_id}`),
  'bulkUpdateMaintenanceVehicleProfiles': (d) => API.put(`/api/maintenance/profiles/vehicle/${d.car_id}/bulk`, { items: d.items }),

  // Notifications
  'getNotifications':    (d) => API.get('/api/notifications' + _q(d)),
  'markNotificationRead':(d) => API.put(`/api/notifications/${d.id}/read`),
  'markAllRead':         ()  => API.put('/api/notifications/read-all'),

  // Admin
  'getUsers':            (d) => API.get('/api/admin/users' + _q(d)),
  'updateUser':          (d) => API.put(`/api/admin/users/${d.id}`, d),
  'deactivateUser':      (d) => API.put(`/api/admin/users/${d.id}/deactivate`, d),
  'deleteUser':          (d) => API.del(`/api/admin/users/${d.id}`),
  'adminResetPassword':  (d) => API.put(`/api/admin/users/${d.id}/reset-password`, d),
  'getUserRequests':     (d) => API.get('/api/admin/requests' + _q(d)),
  'approveUserRequest':  (d) => API.put(`/api/admin/requests/${d.id}/approve`, d),
  'rejectUserRequest':   (d) => API.put(`/api/admin/requests/${d.id}/reject`, d),
  'impersonateUser':     (d) => API.post(`/api/admin/impersonate/${d.id}`),
  'impersonateRole':     (d) => API.post(`/api/admin/impersonate-role/${d.role}`),
  'stopImpersonate':     ()  => API.post('/api/admin/stop-impersonate'),
  'getSettings':         ()  => API.get('/api/admin/settings'),
  'updateSettings':      (d) => API.put('/api/admin/settings', d),
  'getAuditLog':         (d) => API.get('/api/admin/audit-log' + _q(d)),

  // Backup
  'getBackups':          ()  => API.get('/api/backup'),
  'listBackups':         ()  => API.get('/api/backup'),
  'createBackup':        (d) => API.post('/api/backup', d),
  'restoreBackup':       (d) => API.post(`/api/backup/${d.id}/restore`, d),

  // OCR
  'ocrExtract':          (d) => API.post('/api/ocr/extract', d),

  // Vehicle Requests
  'getVehicleRequests':  (d) => API.get('/api/vehicle-requests' + _q(d)),
  'getVehicleRequest':   (d) => API.get(`/api/vehicle-requests/${d.id}`),
  'createVehicleRequest':(d) => API.post('/api/vehicle-requests', d),
  'updateVehicleRequest':(d) => API.put(`/api/vehicle-requests/${d.id}`, d),
  'cancelVehicleRequest':(d) => API.del(`/api/vehicle-requests/${d.id}`),
  'approveVehicleRequest':(d) => API.put(`/api/vehicle-requests/${d.id}/approve`, d),
  'rejectVehicleRequest':(d) => API.put(`/api/vehicle-requests/${d.id}/reject`, d),
  'assignVehicleRequest':(d) => API.put(`/api/vehicle-requests/${d.id}/assign`, d),

  // Survey
  'getSurveyCarInfo':    (d) => API.get(`/api/survey/car-info?car_id=${d.car_id}`),
  'submitSurvey':        (d) => API.post('/api/survey/submit', d),
  'getSurveyResults':    (d) => API.get('/api/survey/results' + _q(d)),

  // Incidents
  'getIncidents':        (d) => API.get('/api/incidents' + _q(d)),
  'getIncident':         (d) => API.get(`/api/incidents/${d.id}`),
  'createIncident':      (d) => API.post('/api/incidents', d),
  'updateIncident':      (d) => API.put(`/api/incidents/${d.id}`, d),
  'resolveIncident':     (d) => API.put(`/api/incidents/${d.id}/resolve`, d),
  'deleteIncident':      (d) => API.del(`/api/incidents/${d.id}`),

  // Inspections (ตรอ.)
  'getInspections':      (d) => API.get('/api/tax-insurance/inspections' + _q(d)),
  'createInspection':    (d) => API.post('/api/tax-insurance/inspections', d),
  'updateInspection':    (d) => API.put(`/api/tax-insurance/inspections/${d.id}`, d),
  'deleteInspection':    (d) => API.del(`/api/tax-insurance/inspections/${d.id}`),

  // Driver Performance
  'getDriverPerformance':    (d) => API.get('/api/reports/driver-performance' + _q(d)),
  'getDriverPerformanceById':(d) => API.get(`/api/reports/driver-performance/${d.id}` + _q(d)),

  // Vehicle Timeline & Cost
  'getVehicleTimeline':  (d) => API.get(`/api/reports/vehicle-timeline/${d.carId}` + _q(d)),
  'getVehicleCost':      (d) => API.get(`/api/reports/vehicle-cost/${d.carId}` + _q(d)),

  // Backward-Compatible Aliases
  'getVehicleById':      (d) => API.get(`/api/vehicles/${d.id || d.carId}`),
  'getAllUsers':         (d) => API.get('/api/admin/users' + _q(d)),
  'createDailyCheck':    (d) => API.post('/api/check/daily', d),
  'createFuelLog':       (d) => API.post('/api/fuel/record', d),
  'getFuelLogs':         (d) => API.get('/api/fuel/log' + _q(d)),
  'getRepairLogs':       (d) => API.get('/api/repair/log' + _q(d)),
  'getRepairLogById':    (d) => API.get(`/api/repair/log/${d.id}`),
  'updateRepairLog':     (d) => API.put(`/api/repair/log/${d.id}`, d),
  'createRepairLog':     (d) => API.post('/api/repair/log', d),
  'updateInsuranceRecord':(d) => API.put(`/api/tax-insurance/insurance/${d.id}`, d),
  'createInsuranceRecord':(d) => API.post('/api/tax-insurance/insurance', d),
  'getMyProfile':        ()  => API.get('/api/auth/me'),
  'updateMyProfile':     (d) => API.put('/api/auth/profile', d),
  'getAuditLogs':        (d) => API.get('/api/admin/audit-log' + _q(d)),
  'updateSystemSetting': (d) => API.put('/api/admin/settings', { [d.key]: d.value }),
  'resetAdminSettingsToDefault': () => API.put('/api/admin/settings', {}),
  'syncStaffNames':      () => API.post('/api/admin/sync-staff-names', {}),
  'getGformSyncConfig':  () => API.get('/api/admin/gform-sync/config'),
  'getGformSyncLog':     (d) => API.get('/api/admin/gform-sync/log' + _q(d)),
  'runGformSync':        () => API.post('/api/admin/gform-sync/run', {}),
  'getUsageRecords':     (d) => API.get('/api/usage' + _q(d)),
  'createUsageRecord':   (d) => API.post('/api/usage', d),
  'submitUsageQR':       (d) => API.post('/api/usage/qr', d),
  'initializeVehicleMaintenanceFromToday': () => API.get('/api/maintenance/schedule'),
  'getAdminSettings':    () => API.get('/api/admin/settings'),
  'getSystemSettings':   () => API.get('/api/admin/settings'),
  'checkPDPAAccepted':   () => API.get('/api/auth/me'),
  'acceptPDPAPolicy':    (d) => API.post('/api/auth/accept-pdpa', d),
  'getCurrentUserInfo':  () => API.get('/api/auth/me'),
  'getQueues':           (d) => API.get('/api/queue' + _q(d)),
};

/** Convert object to query string: { status: 'active' } → '?status=active' */
function _q(obj) {
  if (!obj) return '';
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined && v !== null && k !== 'id') p.append(k, v);
  }
  const s = p.toString();
  return s ? '?' + s : '';
}

/**
 * Legacy-compatible apiCall(action, data)
 * Returns the full envelope { success, data, message } — same interface as original GAS version
 * Throws on network/server error
 */
async function apiCall(action, data) {
  const fn = ACTION_MAP[action];
  if (!fn) throw new Error(`Unknown action: ${action}`);
  const result = await fn(data);
  // result is already the JSON body from the server
  // On success the server returns { success: true, data: ... }
  // API.get/post/put throws on non-2xx, so result.success should always be true here
  return result;
}
